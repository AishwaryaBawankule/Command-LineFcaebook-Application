package com.foundationalproject.CMDFacebookApp.models;

public class Users {

	private String userEmail;
	private String userName;
	private String userAddress;
	private int UserAge;
	private String userGender;
	private String userPassword;
	private String UserCity;

	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public int getUserAge() {
		return UserAge;
	}
	public void setUserAge(int userAge) {
		UserAge = userAge;
	}
	public String getUserGender() {
		return userGender;
	}
	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userpassword) {
		this.userPassword = userpassword;
	}
	public String getUserCity() {
		return UserCity;
	}
	public void setUserCity(String userCity) {
		UserCity = userCity;
	}

}
