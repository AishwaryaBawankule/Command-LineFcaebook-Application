package com.foundationalproject.CMDFacebookApp;

import java.sql.Time;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.foundationalproject.CMDFacebookApp.dao.UserDaoImpl;
import com.foundationalproject.CMDFacebookApp.dao.UserDaoInterface;
import com.foundationalproject.CMDFacebookApp.models.Post;
import com.foundationalproject.CMDFacebookApp.models.Users;

public class Menu {

	public static void signInSignUp() {

		Scanner scan = new Scanner(System.in);

		String choice = "";

		System.out.println("*** WELCOME TO FACEBOOK ***"
				+"\n\n1. Sign up     " +"2.Sign in");
		System.out.println();

		System.out.println("Enter your option");
		int option  = scan.nextInt();



		do {

			UserDaoInterface userDao = new UserDaoImpl();
			switch(option) {

			case 1:
				System.out.println("Enter your email to create profile with facebook");
				String userMail = scan.next();

				System.out.println("Enter your name to create profile with facebook");
				String userName = scan.next();

				System.out.println("Enter your address to create profile with facebook");
				String userAddress = scan.nextLine();

				System.out.println("Enter your age to create profile with facebook");
				int userAge = scan.nextInt();

				System.out.println("Enter your gender to create profile with facebook");
				String userGender = scan.next();

				System.out.println("Enter your password to create profile with facebook");
				String userPassword = scan.next();

				System.out.println("Enter your city to create profile with facebook");
				String userCity = scan.next();

				userDao.createProfile(userMail, userName, userAddress, userAge, userGender, userPassword, userCity);
				break;

			case 2:
				System.out.println("Enter your email id to sign in ");
				String logInMail = scan.next();
				System.out.println("Enter your password sign in ");
				String passToLogin = scan.next();
				userDao.logIn(logInMail, passToLogin);
				break;

			}
			System.out.println("Do you want to continue (yes/no)");
			choice = scan.next();
		}while(choice.equalsIgnoreCase(choice));

	}


	public static void printDetailsOfUser(Users u) {

		String userEmail = u.getUserEmail();
		String userName = u.getUserName();
		String userAddress = u.getUserAddress();
		int userAge = u.getUserAge();
		String userGender = u.getUserGender();
		String userPassword = u.getUserPassword();
		String userCity = u.getUserCity();
		System.out.println("User email : "+userEmail+"\nUser name : "+userName+"\nUser address : "+userAddress+"\nuser age "
				+userAge+"\nUser gender "+userGender+"\nUser password "+userPassword+"\nUser City "+userCity);
		System.out.println();
	}

	public static void printUserName(Users u) {
		String userName = u.getUserName();
		System.out.println("Users : "+userName);
	}

	public static void printPost(Post p) {
		String postMsg = p.getPostMessage();
		Date postDate = p.getPostDate();
		Time postTime = p.getPostTime();

		System.out.println();
		System.out.println("Post message : "+postMsg);
		System.out.println("Post date : "+postDate);
		System.out.println("Post time : "+postTime);
		System.out.println();

	}
	public static void getMenu(String mail) throws InterruptedException {
		Scanner scan = new Scanner(System.in);
		String choice = "";

		do {
			System.out.println("----MENU----"
					+"\n 1. Update profile"
					+"\n 2. Delete profile"
					+"\n 3. View profile"
					+"\n 4. View all profile"
					+"\n 5. Search profile"
					+"\n 6. Create a post"
					+"\n 7. Show timeline"
					+"\n 8. See post created by others"
					+"\n 9. Log out");

			System.out.println("Enter your option");
			int option  = scan.nextInt();

			UserDaoInterface userDao = new UserDaoImpl();
			switch(option) {

			case 1:
				System.out.println("What do you want to update");
				System.out.println("----MENU----"
						+"\n 1. Update name"
						+"\n 2. Update address"
						+"\n 3. Update age"
						+"\n 4. Update gender"
						+"\n 5. Update password"
						+"\n 6. Update city");

				int ch  = scan.nextInt();
				switch(ch) {

				case 1:
					System.out.println("Enter the new name");
					String newName = scan.next();
					userDao.updateProfileName(mail, newName);
					break;

				case 2:
					System.out.println("Enter the new address");
					String newAddress = scan.next();
					userDao.updateProfileAddress(mail, newAddress);
					break;

				case 3:
					System.out.println("Enter the new age");
					int newAge = scan.nextInt();
					userDao.updateProfileAge(mail, newAge);
					break;

				case 4:
					System.out.println("Enter the new gender");
					String newGender = scan.next();
					userDao.updateProfileGender(mail, newGender);
					break;

				case 5:
					System.out.println("Enter the new password");
					String newPassword = scan.next();
					userDao.updateProfilePasssword(mail, newPassword);
					break;

				case 6:
					System.out.println("Enter the new city");
					String newCity = scan.next();
					userDao.updateProfileCity(mail, newCity);
					break;

				}
				break;

			case 2:
				System.out.println("Are you sure you want to delete your profile (yes/no)");
				String choiceTodelete = scan.next();
				if(choiceTodelete.equalsIgnoreCase("yes"))
					userDao.deleteUserByMailId(mail);
				break;

			case 3:
				//				System.out.println("Enter your email to view your profile");
				//				String nameToViewProfile = scan.next();
				Users u1 = userDao.viewProfile(mail);

				printDetailsOfUser(u1);
				break;

			case 4:
				List<Users> userList = userDao.viewAllUsers();
				for(Users u: userList) {
					printUserName(u);
				}
				break;

			case 5:
				System.out.println("Enter some initials of name to search the profile");
				String initialsOfname = scan.next();
				List<Users> searchList = userDao.searchProfile(initialsOfname);
				for(Users u: searchList) {
					printUserName(u);
				}
				break;


			case 6:
				System.out.println("Enter your message to create post");
				scan.nextLine();
				String msg = scan.nextLine();
				userDao.createAPost(mail,msg);
				break;

			case 7:
				userDao.showTimeLine(mail);
				break;

			case 8:
				userDao.seeOthersPost(mail);
				break;

			case 9:
				System.out.println("Log out sucessfully");

				System.out.println();

				System.out.println("Do you want to log in again ??(yes/no)");
				String ch1 = scan.next();
				if(ch1.equalsIgnoreCase("yes")) {

					userDao.logOut();
				}
				else {
					System.out.println("Thank you for using facebook.......have a good day..^_^..");
				}

				break;
			}	
			System.out.println("Do you want to continue in Menu(yes/no)");
			choice = scan.next();
		}while(choice.equalsIgnoreCase("yes"));
	}
}
