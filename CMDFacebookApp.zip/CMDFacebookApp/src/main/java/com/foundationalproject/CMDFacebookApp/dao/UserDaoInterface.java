package com.foundationalproject.CMDFacebookApp.dao;

import java.util.List;

import com.foundationalproject.CMDFacebookApp.models.Post;
import com.foundationalproject.CMDFacebookApp.models.Users;

public interface UserDaoInterface {

	void createProfile(String userEmail, String userName,String userAddress, int UserAge, String userGender, String userpassword,String UserCity);

	void updateProfileName(String userIdToUpdate, String newName);

	void updateProfileAddress(String userEmailIdToUpdate, String newAddress);

	void updateProfileAge(String userEmailIdToUpdate, int newage);

	void updateProfileGender(String userEmailIdToUpdate, String newGender);

	void updateProfilePasssword(String userEmailIdToUpdate, String newPassword);

	void updateProfileCity(String userEmailIdToUpdate, String newCity);

	void deleteUserByMailId(String mailToDelete);

	public Users viewProfile(String emailToViewProfile);

	List<Users> viewAllUsers();

	List<Users> searchProfile(String nameToSearch);

	void logIn(String mailToLogIn, String passToLogIn);

	void createAPost(String mail,String msg);

	void showTimeLine(String mail);

	void seeOthersPost(String mail);

	void logOut();
}
