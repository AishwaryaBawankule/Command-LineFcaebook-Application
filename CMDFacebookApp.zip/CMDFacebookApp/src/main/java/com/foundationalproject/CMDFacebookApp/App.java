package com.foundationalproject.CMDFacebookApp;

import java.util.Scanner;

import com.foundationalproject.CMDFacebookApp.dao.UserDaoImpl;
import com.foundationalproject.CMDFacebookApp.dao.UserDaoInterface;


public class App 
{
	public static void main(String[] args) {

		//		Menu menu = new Menu();
		//		menu.signInSignUp();

		Scanner scan = new Scanner(System.in);

		String choice = "";

		do {

			System.out.println("*** WELCOME TO FACEBOOK ***"
					+"\n\n1. Sign up     " +"2.Sign in");
			System.out.println();

			System.out.println("Enter your option");
			int option  = scan.nextInt();

			UserDaoInterface userDao = new UserDaoImpl();
			switch(option) {

			case 1:
				System.out.println("Enter your email to create profile with facebook");
				String userMail = scan.next();

				System.out.println("Enter your name to create profile with facebook");
				String userName = scan.next();

				scan.nextLine();
				System.out.println("Enter your address to create profile with facebook");
				String userAddress = scan.nextLine();

				System.out.println("Enter your age to create profile with facebook");
				int userAge = scan.nextInt();

				System.out.println("Enter your gender to create profile with facebook");
				String userGender = scan.next();

				System.out.println("Enter your password to create profile with facebook");
				String userPassword = scan.next();

				System.out.println("Enter your city to create profile with facebook");
				String userCity = scan.next();

				userDao.createProfile(userMail, userName, userAddress, userAge, userGender, userPassword, userCity);
				break;

			case 2:
				System.out.println("Enter your email id to sign in ");
				String logInMail = scan.next();
				System.out.println("Enter your password sign in ");
				String passToLogin = scan.next();
				userDao.logIn(logInMail, passToLogin);
				break;

			}
			System.out.println("Do you want to continue in App(yes/no)");
			choice = scan.next();
		}while(choice.equalsIgnoreCase("yes"));	
	}

}