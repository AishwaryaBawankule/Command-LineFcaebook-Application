package com.foundationalproject.CMDFacebookApp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.foundationalproject.CMDFacebookApp.App;
import com.foundationalproject.CMDFacebookApp.Menu;
import com.foundationalproject.CMDFacebookApp.models.Post;
import com.foundationalproject.CMDFacebookApp.models.Users;
import com.foundationalproject.CMDFacebookApp.util.ConnectionUtil;

public class UserDaoImpl implements UserDaoInterface{

	public void createProfile(String userEmail, String userName, String userAddress,int userAge, String userGender, String userpassword, String userCity) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("insert into facebookUser "
					+ "values( ?, ?, ?, ?, ?, ?, ?)");			

			preparedStatement.setString(1, userEmail);
			preparedStatement.setString(2, userName);
			preparedStatement.setString(3, userAddress);
			preparedStatement.setInt(4, userAge);
			preparedStatement.setString(5, userGender);
			preparedStatement.setString(6, userpassword);
			preparedStatement.setString(7, userCity);


			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Profile created sucessfully");
				Users user = new Users();
				user.setUserEmail(userEmail);
				user.setUserName(userName);
				user.setUserAddress(userAddress);
				user.setUserAge(userAge);
				user.setUserGender(userGender);
				user.setUserPassword(userpassword);
				user.setUserCity(userCity);
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void deleteUserByMailId(String mailToDelete) {

		try {
			Connection cn = ConnectionUtil.getConnection();			

			PreparedStatement preparedStatement = cn.prepareStatement("delete from facebookUser where userMail = ?");

			preparedStatement.setString(1, mailToDelete);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Profile is deleted");
			}

		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}


	public Users viewProfile(String emailToViewProfile) {
		Users u = new Users();
		try {
			Connection cn = ConnectionUtil.getConnection();
			PreparedStatement preparedStatement = cn.prepareStatement
					("select * from facebookUser where userEmail = ?");
			preparedStatement.setString(1, emailToViewProfile);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {

				String userEmail = rs.getString(1);
				String userName = rs.getString(2);
				String userAddress = rs.getString(3);
				int userAge = rs.getInt(4);
				String userGender = rs.getString(5);
				String userpassword = rs.getString(6);
				String userCity = rs.getString(7);

				u.setUserEmail(userEmail);
				u.setUserName(userName);
				u.setUserAddress(userAddress);
				u.setUserAge(userAge);
				u.setUserGender(userGender);
				u.setUserPassword(userpassword);
				u.setUserCity(userCity);
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return u;
	}

	public List<Users> viewAllUsers() {
		List<Users> userList = new ArrayList<Users>();
		try {
			Connection cn = ConnectionUtil.getConnection();
			Statement stmt = cn.createStatement();
			ResultSet rs = stmt.executeQuery("Select userName from facebookUser");

			while(rs.next()) {
				Users u = new Users();

				String userName = rs.getString(1);

				u.setUserName(userName);

				userList.add(u);
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return userList;
	}

	public void updateProfileName(String userIdToUpdate, String newName) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set userName = ? where userEmail = ?");

			preparedStatement.setString(1, newName);
			preparedStatement.setString(2, userIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Name is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void updateProfileAddress(String userEmailIdToUpdate, String newAddress) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set address = ? where userEmail = ?");

			preparedStatement.setString(1, newAddress);
			preparedStatement.setString(2, userEmailIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Address is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void updateProfileAge(String userEmailIdToUpdate, int newage) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set userAge = ? where userEmail = ?");

			preparedStatement.setInt(1, newage);
			preparedStatement.setString(2, userEmailIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Age is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void updateProfileGender(String userEmailIdToUpdate, String newGender) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set userGender = ? where userEmail = ?");

			preparedStatement.setString(1, newGender);
			preparedStatement.setString(2, userEmailIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Gender is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void updateProfilePasssword(String userEmailIdToUpdate, String newPassword) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set userPassword = ? where userEmail = ?");

			preparedStatement.setString(1, newPassword);
			preparedStatement.setString(2, userEmailIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Password is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void updateProfileCity(String userEmailIdToUpdate, String newCity) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement("update facebookUser set userCity = ? where userEmail = ?");

			preparedStatement.setString(1, newCity);
			preparedStatement.setString(2, userEmailIdToUpdate);

			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("City is Updated for the given email id");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public List<Users> searchProfile(String nameToSearch) {
		List<Users> searchList = new ArrayList<Users>();
		try {
			Connection cn = ConnectionUtil.getConnection();			
			PreparedStatement preparedStatement = cn.prepareStatement
					("Select userName, userAge, userGender, userCity "
							+ "from facebookUser where userName like ?");
			preparedStatement.setString(1, nameToSearch+"%");
			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()) {
				Users u = new Users();
				String userName = rs.getString(1);
				int userAge = rs.getInt(2);
				String userGender = rs.getString(3);
				String userCity = rs.getString(4);

				u.setUserName(userName);
				u.setUserAge(userAge);
				u.setUserGender(userGender);
				u.setUserCity(userCity);

				searchList.add(u);
			}
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return searchList;
	}

	public void logIn(String mailToLogIn, String passToLogIn) {
		Users u = new Users();
		try {
			Connection cn = ConnectionUtil.getConnection();
			String mailCheck = "select userEmail from facebookUser where userEmail= ? ";
			PreparedStatement prepStmt = cn.prepareStatement(mailCheck);
			prepStmt.setString(1, mailToLogIn);
			ResultSet rs = prepStmt.executeQuery();
			boolean checkMail = false;

			if (rs.next()) {
				checkMail = true;
				String passCheck = "select userPassword from facebookUser where userEmail = ? ";
				PreparedStatement prepStmt1 = cn.prepareStatement(passCheck);
				prepStmt1.setString(1, mailToLogIn);
				ResultSet rs1 = prepStmt1.executeQuery();
				boolean checkPass = false;

				while(rs1.next()) {
					String actualPass = rs1.getString(1);
					if(actualPass.equals(passToLogIn)) {
						Menu.getMenu(mailToLogIn);
					}
					else {
						System.out.println("Your password is incorrect ");
					}
				}
			}
			else {
				System.out.println("Mail id not exist , register yourself first");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createAPost(String mail,String msg) {

		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement
					("insert into usersPost(postmessage,useremail,postTime,postDate) values "
							+ "(?,?,current_time(),current_date())");

			preparedStatement.setString(1, msg);
			preparedStatement.setString(2, mail);
			if(preparedStatement.executeUpdate() == 1) {
				System.out.println("Post created sucessfully");
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void showTimeLine(String mail) {
		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement
					("select postmessage,postTime,postDate from "
							+ "usersPost where useremail = ?");
			preparedStatement.setString(1, mail);
			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()) {

				System.out.println();
				String postmessage = rs.getString(1);
				System.out.println("Post : "+postmessage);
				Date date = rs.getDate(3);
				Time time = rs.getTime(2);
				System.out.println("Posted on :"+date+" "+time);
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void seeOthersPost(String mail) {

		try {
			Connection cn = ConnectionUtil.getConnection();

			PreparedStatement preparedStatement = cn.prepareStatement
					("select u.userName,p.postmessage,p.postdate,p.postTime from "
							+ "facebookUser u inner join usersPost p on u. userEmail = p. useremail where"
							+ " u.userEmail <> ?");

			preparedStatement.setString(1, mail);
			ResultSet rs = preparedStatement.executeQuery();

			while(rs.next()) {

				System.out.println();
				String userName = rs.getString(1);
				System.out.println("Posted by : "+userName);
				String postmessage = rs.getString(2);
				System.out.println("Post : "+postmessage);
				Date date = rs.getDate(3);
				Time time = rs.getTime(4);
				System.out.println("Posted on :"+date+" "
						+time);
			}

		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void logOut() {

		Menu.signInSignUp();

	}


}